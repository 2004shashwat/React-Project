import React from 'react'
import './App.css'
import First from './Components/Firstpage'
import Second from './Components/Secondpage'
import Third from './Components/Thirdpage'
import Fourth from './Components/Fouthpage'
import Fifth from './Components/Fifthpage'
import Sixth from './Components/Sixthpage'
import Seventh from './Components/Seventhpage'
import Eight from './Components/Eightpage'
import Ninth from './Components/Ninthpage'
import Tenth from './Components/Tenthpage'

function App() {
  

  return (
    <>
      <First/>
      <Second/>
      <Third/>
      <Fourth/>
      <Fifth/>
      <Sixth/>
      <Seventh/>
      <Eight/>
      <Ninth/>
      <Tenth/>
    </>
  )
}

export default App
