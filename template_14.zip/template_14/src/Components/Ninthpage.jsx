import React from "react";

const Ninth =()=>{
    return(
        <>
        <div className="pg7">
          <div className="text6">
            <h1>Get Our Latest Offers!</h1>
            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique
              beatae officiis repudiandae repellat labore accusantium?
            </p>
          </div>
          <div className="bttn4">
            <input type="text" placeholder="Your Email" className="button4" />
            <div className="bttn5">
              <button className="button5">SUBSCRIBE</button>
            </div>
          </div>
        </div>
        </>
    )
}
export default Ninth