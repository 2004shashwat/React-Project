import React from "react";

const Sixth =()=>{
    return(
    <>
<div className="pg4" id="o">
          <div className="text3">
            <h4>25%</h4>
            <h5>DISCOUNT</h5>
            <div className="pht1">
              <img src="Images/Bite.png" />
              <h6>ON TACOS!</h6>
            </div>
          </div>
        </div>
        <br />
    </>
    )
}
export default Sixth