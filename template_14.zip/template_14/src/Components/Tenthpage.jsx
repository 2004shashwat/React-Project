import React from "react";

const Tenth =()=>{
    return(
        <>
         <div className="pg8" id="c">
          <div className="text7">
            <h1>Mariachi</h1>
            <p>
              Lorem ipsum dolor sit amet cone,adipisicing elit. Magni iste suscipitdi
              stinctiosunt minima omnis nobis at, cumque quisquam. optiosit libero.
            </p>
            <div className="lg">
              <img className="fb" src="Images/Fb.png" />
              <img className="ig" src="Images/Ig.png" />
              <img className="tw" src="Images/Tw.png" />
              <img className="ws" src="Images/Ws.png" />
            </div>
          </div>
          <div className="text8">
            <h1>About</h1>
            <div className="l1">History</div>
            <div className="l2">Our Team</div>
            <div className="l3">Brand Guidelines</div>
            <div className="l4">Terms&amp;Condition</div>
            <div className="l5">Privacy Policy</div>
          </div>
          <div className="text9">
            <h1>Services</h1>
            <div className="l1">How To Order</div>
            <div className="l2">Our Products</div>
            <div className="l3">Offers</div>
            <div className="l4">Promo</div>
            <div className="l5">Payment Method</div>
          </div>
          <div className="text10">
            <h1>Other</h1>
            <div className="l1">Contact Us</div>
            <div className="l2">Help</div>
            <div className="l3">Feedback</div>
            <div className="l4">Any Other Query</div>
          </div>
          <button className="up"><a href="#up">Scroll up</a></button>
        </div>
        </>
    )
}
export default Tenth