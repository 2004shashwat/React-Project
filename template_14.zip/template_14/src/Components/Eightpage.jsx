import React from "react";

const Eight =()=>{
    return(
    <>
<div className="pg6">
          <div className="lg1">
            <img src="Images/logo.png" />
          </div>
          <div className="text5">
            <p1>
              Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro facere
              nesciunt recusandae accusantium possimus facilis ratione
              inventore!Labore omnis ullam distinctio earum laborum tempore nesciunt
              dolor temporibus.
            </p1>
            <h1>
              <b>Pedro Rodriguez</b>
            </h1>
          </div>
        </div>
    </>
    )
}
export default Eight