import React from "react";

const Third =()=>{
    return(
    <>
<div className="pg2" id="menu">
          <div className="text1">
            <h2>Don't Miss our Menu!</h2>
            <p1>
              Lorem ipsum, dolor sit amet consectetur adipisicing elit. Perferendis
              quos et laborum. vel ullam, laudantium deleniti quis molestiae Minus,
              quis Cumque ducimus id incidunt!
            </p1>
          </div>
          <div className="buttn1">
            <button className="button1">
              <b>SEE MENU</b>
            </button>
          </div>
        </div>
    </>
    )
}
export default Third