import React from "react";

const Fifth =()=>{
    return(
    <>
<div className="pg3" id="a">
          <div className="Circle1">
            <img src="Images/Circle1.png" />
          </div>
          <div className="text2">
            <h3>About Mariachi</h3>
            <p2>
              Lorem ipsum dolor sit amet, consectetur adipisicing elit. Distinctio,
              repudiandae facere dicta sit repellend voluptatibus? adipisicing elit.
              Sed quidem voluptatem tenetur laudantium modi. Culpa nemo earum!
            </p2>
            <div className="buttn2">
              <button className="button2">
                <b>TELL ME MORE</b>
              </button>
            </div>
          </div>
        </div>
    </>
    )
}
export default Fifth