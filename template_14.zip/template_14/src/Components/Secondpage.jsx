import React from "react";

const Second =()=>{
    return(
    <>
<div className="pg1">
          <div className="lg">
            <img src="Images/logo.png" />
          </div>
          <div className="text">
            <h1>Maraichi</h1>
            <p>
              Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maiores unde
              assumenda dignissimos eum natus, autem maxime perferendis!
            </p>
          </div>
          <div className="buttn">
            <a href="#">
              <button className="button">
                <b>ORDER NOW</b>
              </button>
            </a>
          </div>
        </div>
    </>
    )
}
export default Second