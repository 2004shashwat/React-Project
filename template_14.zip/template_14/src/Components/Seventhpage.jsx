import React from "react";

const Seventh =()=>{
    return(
    <>
<div className="pg5">
          <div className="text4">
            <h1>See our Offers</h1>
            <p1>
              Lorem ipsum dolor sit amet consectetur, adipisicing elit. Exercitationem
              ea molestias dicta nobis maxime quas ipsam nesciunt minus sit!
            </p1>
            <div className="buttn3">
              <button className="button3">
                <b>SEE OFFERS</b>
              </button>
            </div>
          </div>
          <div className="Circle2">
            <img src="Images/Circle2.png" />
          </div>
        </div>
    </>
    )
}
export default Seventh