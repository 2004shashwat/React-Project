import React from "react";

const Fourth =()=>{
    return(
    <>
<div className="pht">
          <img
            src="Images/Rectángulo.png"
            style={{ width: "100%", height: "100%" }}
          />
        </div>
    </>
    )
}
export default Fourth